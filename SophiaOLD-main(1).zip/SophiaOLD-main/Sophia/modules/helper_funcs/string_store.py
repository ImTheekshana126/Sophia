GDNIGHT = [
    "Good night!",
]

GDMORNING = [
    "Good morning!",
]

SOPHIA = [
     "Something went wrong.",
     "Something went wrong.",
     "Nope.",
     "Nope.",
     "Nope.",
     "Nope.",
     "Nope.",
     "Something went wrong.",
     "Maybe.",
     "Something went wrong.",
     "Something went wrong.",
     "Nope.",
     "Nope.",
     "Nope.",
     "Nope.",
     "Nope.",
     "Something went wrong.",
     "Maybe.",
     "Something went wrong.",
     "Something went wrong.",
     "Nope.",
     "Nope.",
     "Nope.",
     "Nope.",
     "Nope.",
     "Something went wrong.",
     "Maybe.",
]







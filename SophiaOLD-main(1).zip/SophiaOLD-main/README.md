<h1 align="center"><b> ❤️ Sophia 2.0  ❤️ OLD</b></h1>

<h1 align="center">Go to New Source Code https://github.com/dihanofficial/sophiabot</h1>
 
<h4 align="center">A Powerful, Smart And Simple Group Manager <br> ... Written with  Pyrogram and Telethon...</h4>
<p align='center'>
  <a href="https://www.python.org/" alt="made-with-python"> <img src="https://img.shields.io/badge/Made%20with-Python-1f425f.svg?style=flat-square&logo=python&color=blue" /> </a>
  <a href="https://github.com/dihanofficial/sophiaold/graphs/commit-activity" alt="Maintenance"> <img src="https://img.shields.io/badge/Maintained%3F-yes-green.svg?style=flat-square" /> </a>
</p>

<p align="center"><a href="https://t.me/Dihan_Official"><img src="https://telegra.ph/file/2767f9592cb8e7d462dd0.png" width="400"></a></p>
<p align="center">
    
> ⭐️ Thanks to everyone who starred Sophia, That is the greatest pleasure we have !


## Avaiilable on Telegram as [@SophiaSLBot](https://t.me/sophiaslbot)



# 🏃‍♂️ Easy Deploy 
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/dihanofficial/Sophiaold.git)



# ❤️ Support
<a href="https://t.me/Dihan_Official"><img src="https://img.shields.io/badge/Join-Telegram%20Channel-red.svg?logo=Telegram"></a>
<a href="https://t.me/DihanOfficial"><img src="https://img.shields.io/badge/Join-Telegram%20Group-blue.svg?logo=telegram"></a>

### Self-hosting (For Devs) ⚔
```sh
# Install Git First (apt-instll git)
$ git clone https://github.com/DihanOfficial/Sophia
$ cd Sophia
# Upgrade sources
$ bash deploy.sh
# Install All Requirements 
$ pip3 install -r requirements.txt
# Rename ./Sophia/data/bot_conf.yaml.example to bot_conf.yaml and fill
# Start Bot 
$ python3 -m Sophia
```

### Mandatory Vars 📒
```
[+] Make Sure You Add All These Mandatory Vars. 
    [-] APP_ID:   You can get this value from https://my.telegram.org
    [-] APP_HASH :   You can get this value from https://my.telegram.org
    [-] STRINGSESSION : Your String Session, You can get this From Repl or BY running String_Gen File Locally
    [-] MONGO_URI : Your Mongo DB DataBase Url. .
    [-] TOKEN: Get from botfarther
    [-] DATABASE_URL: from elephantsql.com
    [-] OWNER_ID: ur id
    [-] MONGO_PORT: 27017
    [-] MONGO_DB': 'Sophia'
 
[+] The Sophia won't run without setting the mandatory vars.
```

# 😍 Credits

 - [FridayUserbot](https://github.com/DevsExpo/FridayUserbot)
 - [MissJuliaRobot](https://github.com/MissJuliaRobot/MissJuliaRobot)
 - [DaisyX](https://github.com/teamdaisyx/daisy-x)
 - [ADV-Auto-Filter-Bot-V2](https://github.com/AlbertEinsteinTG/Adv-Auto-Filter-Bot-V2)
 - [Image-Editor](https://github.com/TroJanzHEX/Image-Editor/)
 - [WilliamButcherBot](https://github.com/thehamkercat/WilliamButcherBot)


## Special Credits

- [Daisy](https://github.com/teamdaisyx/daisy-Old)
- [TroJanzHEX](https://github.com/TroJanzHEX)
- [infotechbro](https://github.com/infotechbro/)
- [Thehamkercat](https://github.com/thehamkercat)





## Devs & Contributors

#### • Dihan Randila (OWNER) 
#### • Matheesha Official (DEV)
#### • Damantha (DEV)
#### • Sadew (DEV)

## All who helped at a glance 

> This project exists thanks to these awesome developers and their codes and contributions.


> And credits goes to all who supported, all who helped and API & environmental equirement package devs and all projects helped in making this project.
> Special thanks to you for using bot

### COPYRIGHT 2020-2021 SOPHIA v2

